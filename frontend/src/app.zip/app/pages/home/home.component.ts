import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/model/product';
import { ProductService } from 'src/app/services/product.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  products!: Product[];
  constructor(productService: ProductService) {
    localStorage.removeItem('cId');
    localStorage.removeItem('key');
    productService.getDiscountProducts().subscribe((data: any) => {
      console.log(data);
      this.products = data;
    });
  }

  ngOnInit(): void { }

  addcId(cId: string) {
    localStorage.setItem('cId', cId);
    location.href = '/prodDetails';
  }
}
